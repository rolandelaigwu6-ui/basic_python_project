# Task 16 — Compatibility, copying and explicit repair boundaries

Marks: 5/100. Independent exercise.

## Required function
```python
def upgrade_records(records):
    ...
```

## Examination question
A legacy log is a list of dicts with required unique nonblank trimmed string id. Each may lack notes. Return a deep copy with notes=[] added only where absent. Existing notes must be a list of strings; preserve it exactly. Preserve every extra field. Wrong argument, entry, id, notes or note-member types raise TypeError; missing/blank/untrimmed/duplicate IDs raise ValueError. An existing notes=None is invalid, not legacy. Never modify source, even if a late record fails.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
