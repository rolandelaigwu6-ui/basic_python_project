# Task 17 — I/O injection, loops and termination

Marks: 5/100. Independent exercise.

## Required function
```python
def read_answer(prompt, input_fn=input, output_fn=print):
    ...
```

## Examination question
Read one of A/B/C/D. Strip and uppercase entered strings. Invalid answers print exactly "Invalid choice. Enter A, B, C or D." then retry. Return the first valid normalized answer; never read another after success. Propagate EOFError and KeyboardInterrupt; do not loop forever on terminal closure. No global input replacement is needed: use injected functions.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
