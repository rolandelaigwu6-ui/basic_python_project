# Task 06 — Validate before mutation and exceptions

Marks: 5/100. Independent exercise.

## Required function
```python
def reserve_stock(items, code, amount):
    ...
```

## Examination question
items is a valid dict mapping codes to {"stock": nonnegative int, ...}. Assume this existing structure is valid; preserve extra fields. code must be a string naming an existing entry; amount a built-in positive int. Wrong argument types raise TypeError. Unknown code, nonpositive amount or insufficient stock raises ValueError. On success deduct amount and return remaining stock. On failure preserve the entire nested collection. Do not add or delete entries.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
