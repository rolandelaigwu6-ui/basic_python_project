# Task 13 — JSON syntax versus business validity

Marks: 5/100. Independent exercise.

## Required function
```python
def decode_catalog(text):
    ...
```

## Examination question
Accept a JSON string encoding a list of objects with required id, name, quantity. id is a unique nonblank already-trimmed string; name is a nonblank already-trimmed string; quantity is a built-in nonnegative int. Extra keys are allowed. Return decoded records. Wrong input text type raises TypeError. Invalid JSON, malformed schema, incorrect decoded field types, duplicate record IDs, or duplicate JSON member names at any depth raise ValueError. Do not repair data. No file I/O.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
