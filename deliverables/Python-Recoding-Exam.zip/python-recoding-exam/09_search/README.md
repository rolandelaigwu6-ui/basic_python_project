# Task 09 — Comprehensions, casefold, AND filters and copies

Marks: 5/100. Independent exercise.

## Required function
```python
def find_records(records, text="", category="", status="", priority=""):
    ...
```

## Examination question
Assume records are valid ticket-like dictionaries. Return deep-copied matches in original order. Match stripped/casefolded text as a title substring. Optional filters are stripped and casefolded then matched to canonical choices: categories Network/Hardware/Software/Other; statuses open/in_progress/resolved; priorities critical/high/medium/low. Empty/whitespace filters impose no restriction. ALL supplied filters must match. Incorrect filter types raise TypeError; invalid choices raise ValueError even when records is empty. Do not change inputs. No fuzzy matching or punctuation removal.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
