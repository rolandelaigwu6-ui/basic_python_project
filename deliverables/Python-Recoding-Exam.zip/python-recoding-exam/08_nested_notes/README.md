# Task 08 — Nested lists, validation, ID continuity and aliasing

Marks: 5/100. Independent exercise.

## Required function
```python
def append_note(record, author, message):
    ...
```

## Examination question
record is a valid dict with status and notes; notes contain unique valid N IDs, author and message. IDs follow the at-least-three-digit canonical rule used in Task 04, with prefix N. Existing data may be assumed valid. Only open/in_progress accepts a note. author/message must be strings, trimmed before storage; author nonblank, message length 5–300 inclusive after trimming. Wrong types raise TypeError, invalid content/status ValueError. Allocate max numeric note ID+1 (N001 if empty), append, return a detached deep copy of the new note. Reject without changing anything or consuming an ID.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
