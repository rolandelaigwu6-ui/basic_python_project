# Task 07 — State machines and guarded assignment

Marks: 5/100. Independent exercise.

## Required function
```python
def apply_action(records, record_id, action, staff=None):
    ...
```

## Examination question
records is a valid list of dicts with id, status, assigned_to, notes. IDs are unique strings. Statuses are open, in_progress, resolved; assigned_to is None or a nonblank label. Existing data may be assumed valid. Find record_id; unknown IDs raise ValueError. Actions: assign, start, resolve, reopen. assign requires a nonblank string staff, trimmed before storing; reject assignment on resolved records. start requires open with assignment. resolve requires in_progress. reopen requires resolved. Preserve assignment and notes through status changes. Unknown/illegal actions raise ValueError. record_id and action must be strings; wrong types raise TypeError. For assign, wrong staff type raises TypeError, blank staff ValueError. Return a deep copy of the updated record. Every rejected action must preserve the whole collection.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
