# Task 04 — Parsing, ASCII digits and numeric ordering

Marks: 5/100. Independent exercise.

## Required function
```python
def next_code(codes):
    ...
```

## Examination question
codes is a list of unique ID strings. An ID is R plus a positive ASCII integer formatted to at least three digits, with no extra zero padding: R001, R010, R999, R1000 are valid; R1, R000, R0001, whitespace and Unicode digits are invalid. Return the next ID after the highest number, or R001 for an empty list. Do not change codes. Wrong container/member types raise TypeError; invalid spelling or duplicates raise ValueError.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
