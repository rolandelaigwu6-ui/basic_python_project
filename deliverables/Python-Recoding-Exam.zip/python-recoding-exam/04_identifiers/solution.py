"""Candidate implementation. Follow README.md; no solution is provided."""

def next_code(codes):
    raise NotImplementedError("Implement this examination task")
