# Task 20 — unittest, debugging and regression evidence

Marks: 5/100. Independent exercise.

## Required function
```python
def transfer(balances, source, target, amount):
    ...
```

## Examination question
This task supplies an intentionally faulty implementation in solution.py. Diagnose and repair it. balances maps account labels to built-in nonnegative integer balances; assume valid existing data. source and target must be existing distinct string keys. amount must be a built-in positive int not exceeding source balance. Wrong argument types raise TypeError; invalid actions raise ValueError. Transfer the amount, preserve total funds, return None. On failure preserve all balances. Add at least TWO original tests in test_candidate.py beyond supplied tests. Before fixing, record a real failing run in investigation.md with initial state, expected/actual results, cause and correction. Do not merely delete assertions.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
