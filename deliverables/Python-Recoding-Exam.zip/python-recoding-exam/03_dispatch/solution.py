"""Candidate implementation. Follow README.md; no solution is provided."""

def dispatch_level(severity, people):
    raise NotImplementedError("Implement this examination task")
