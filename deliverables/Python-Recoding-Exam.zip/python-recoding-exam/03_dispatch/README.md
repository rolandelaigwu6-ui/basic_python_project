# Task 03 — Condition precedence and pure functions

Marks: 5/100. Independent exercise.

## Required function
```python
def dispatch_level(severity, people):
    ...
```

## Examination question
For an emergency drill, severity must be exactly low, medium or high; no normalization. people must be a built-in positive int. Incorrect types raise TypeError, other invalid values ValueError. Return critical for high severity AND at least 10 people; otherwise high for high severity OR at least 10 people; otherwise medium for medium severity OR at least 3 people; otherwise low. Do not use input/output.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
