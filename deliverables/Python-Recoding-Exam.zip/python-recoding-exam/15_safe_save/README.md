# Task 15 — JSON writing, temporary files and cleanup

Marks: 5/100. Independent exercise.

## Required function
```python
def save_snapshot(records, path):
    ...
```

## Examination question
records is a JSON-serializable list of dictionaries; validate container and entry types (TypeError on mismatch), but no business schema is required. Write complete UTF-8 JSON using a temporary file in the destination directory, close it, then os.replace(temp_path, path). Import os and call os.replace so the supplied test can simulate failure. Reject NaN/Infinity with ValueError rather than emitting nonstandard JSON. Preserve an existing destination on validation, encoding or replacement failure. Remove temporary files on failure. Return None. Do not change records. Parent directory already exists; paths are pathlib.Path or strings.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
