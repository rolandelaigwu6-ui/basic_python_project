# Task 11 — Counting dictionaries, percentages and reconciliation

Marks: 5/100. Independent exercise.

## Required function
```python
def summarize(records):
    ...
```

## Examination question
Assume valid records with canonical category/status/priority. Return exactly total, by_status, by_priority, by_category, unresolved, resolved, resolution_percentage. Include zero counts for all options from Task 09. unresolved=open+in_progress. Use current status only; percentage=resolved/total*100, or 0.0 if empty. Do not round or mutate input. Each record counts once in each grouping.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
