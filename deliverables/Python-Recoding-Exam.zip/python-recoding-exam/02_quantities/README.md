# Task 02 — Types, booleans and integer boundaries

Marks: 5/100. Independent exercise.

## Required function
```python
def validate_quantity(value):
    ...
```

## Examination question
Accept only a built-in int in the inclusive interval 1–500. Return the value unchanged. Reject every other type, including bool, float, numeric strings and int subclasses, with TypeError. Out-of-range built-in integers raise ValueError. No coercion.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
