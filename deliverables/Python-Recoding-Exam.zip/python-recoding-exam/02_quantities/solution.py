"""Candidate implementation. Follow README.md; no solution is provided."""

def validate_quantity(value):
    raise NotImplementedError("Implement this examination task")
