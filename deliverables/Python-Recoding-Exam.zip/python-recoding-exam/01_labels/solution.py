"""Candidate implementation. Follow README.md; no solution is provided."""

def normalize_label(value):
    raise NotImplementedError("Implement this examination task")
