# Task 01 — Strings, whitespace and Unicode

Marks: 5/100. Independent exercise.

## Required function
```python
def normalize_label(value):
    ...
```

## Examination question
A library needs consistent reader labels. Accept a string, strip surrounding whitespace, collapse internal whitespace runs to a single space, then casefold. Reject nonstrings with TypeError and an empty cleaned label with ValueError. Return the cleaned string. Do not print or read input.
Example: "  STRAẞE   Club " → "strasse club".

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
