# Task 12 — Whole-collection validation and uniqueness scopes

Marks: 5/100. Independent exercise.

## Required function
```python
def validate_batches(records):
    ...
```

## Examination question
Validate a list of dicts with required id and notes fields. id must be a nonblank already-trimmed string unique across records. notes must be a list of dicts with required note_id and message. Both note fields must be nonblank already-trimmed strings; note_id is unique within its record only. Extra fields are allowed. Return None; never mutate. Wrong container/field types raise TypeError; missing fields, duplicate IDs or invalid strings raise ValueError. This deliberately uses arbitrary string IDs, not the numeric format from earlier tasks.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
