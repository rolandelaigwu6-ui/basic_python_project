# Task 05 — Dictionaries, required keys and invariants

Marks: 5/100. Independent exercise.

## Required function
```python
def validate_device(record):
    ...
```

## Examination question
Require a dict with keys serial, label, stock, state. Extra keys are allowed. serial and label must be strings that are nonempty and already trimmed. stock must be a built-in int >=0. state is exactly available or retired. A retired device must have stock=0. Return None on success. Wrong record/field types raise TypeError; missing keys or invalid values raise ValueError. Do not mutate the record.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
