# Task 19 — Interactive composition and first-submission integrity

Marks: 5/100. Independent exercise.

## Required function
```python
def run_check(bank, input_fn=input, output_fn=print):
    ...
```

## Examination question
Assume a valid six-question bank, each with id, prompt, options (dict A–D to text) and correct. Display each prompt and all four options. Collect one valid A/B/C/D answer per question, normalizing strip/uppercase and retrying invalid inputs with friendly feedback. A valid wrong answer cannot be revised. After all six answers, collect nonblank trimmed explanations for the first two questions, retrying blank explanations. Return exactly {"answers": list, "score": int, "explanations": {first_id: str, second_id: str}}. Display final score as "Score: n/6". Explanations are not graded. Propagate EOFError/KeyboardInterrupt. No cross-folder imports.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
