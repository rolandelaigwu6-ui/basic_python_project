# Task 18 — Separation of data and logic; exact scoring

Marks: 5/100. Independent exercise.

## Required function
```python
def score_answers(bank, answers):
    ...
```

## Examination question
bank is a list of dictionaries with id and correct. IDs are unique nonblank strings; correct is exactly A/B/C/D. answers is a list of equal length containing canonical A/B/C/D choices. Return count of equal corresponding answers; empty lists score 0. Wrong top-level/member/field types raise TypeError; missing keys, duplicate/blank IDs, invalid choice or length mismatch raises ValueError. Do not normalize submitted answers or mutate anything. Questions may be reordered: use their supplied correct values, not a memorized key.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
