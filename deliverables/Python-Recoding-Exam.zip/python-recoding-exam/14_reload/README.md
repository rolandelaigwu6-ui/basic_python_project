# Task 14 — File reading, exceptions and transactional replacement

Marks: 5/100. Independent exercise.

## Required function
```python
def reload_catalog(current, path):
    ...
```

## Examination question
current is a list whose identity must remain unchanged. Read path as UTF-8, validate using the exact Task 13 catalog contract, then replace current contents only after complete success. Return None. File failures propagate as OSError; invalid content raises ValueError. No file should be modified. This task contains its own supplied dependency decoder.py; do not edit it or import another exercise. A valid empty file payload [] clears memory; a missing file must not.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
