# Task 10 — Sorting keys and regression preservation

Marks: 5/100. Independent exercise.

## Required function
```python
def open_queue(records):
    ...
```

## Examination question
Assume valid records with canonical T IDs, status, priority, and optional nested extras. Return detached copies of only open records sorted critical, high, medium, low, then numeric ID ascending. Preserve original order and data. Do not include in_progress or resolved records.

## Submission
Implement solution.py. Keep supplied tests unchanged. Add a meaningful test_candidate.py and be ready to defend your choices.

## Run
```sh
python -m unittest discover -s . -p 'test_*.py' -v
```
